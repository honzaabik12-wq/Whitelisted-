# CZ/SK Styl Emergency Hamburg – Whitelist Portal

Moderní Next.js aplikace pro Roblox Emergency Hamburg. Obsahuje veřejný whitelist formulář, kontrolu stavu žádosti a A-TEAM administraci.

## 1. Co potřebuješ
- GitHub účet
- Vercel účet
- Supabase účet a nový projekt

## 2. Databáze Supabase
1. V Supabase otevři svůj projekt.
2. Vyber **SQL Editor** → **New query**.
3. Zkopíruj celý obsah `supabase/schema.sql` a spusť jej.
4. V **Project Settings → API** si připrav Project URL a `service_role` key. Service role key je tajný – nikdy ho nevkládej do veřejného kódu ani do `NEXT_PUBLIC_` proměnné.

## 3. Spuštění lokálně
1. Rozbal ZIP a otevři složku projektu v editoru (např. VS Code).
2. Vytvoř soubor `.env.local` podle `.env.example`.
3. Vyplň `NEXT_PUBLIC_SUPABASE_URL` a `SUPABASE_SERVICE_ROLE_KEY`.
4. Nastav `ADMIN_PASSWORD`. Počáteční heslo může být `1923`, ale před zveřejněním ho změň na silné unikátní heslo.
5. Vygeneruj dlouhý náhodný `ADMIN_SESSION_SECRET` (alespoň 32 znaků).
6. V terminálu spusť:
   ```bash
   npm install
   npm run dev
   ```
7. Otevři http://localhost:3000

## 4. Nasazení na Vercel
1. Nahraj projekt do nového GitHub repository.
2. Ve Vercelu zvol **Add New → Project** a importuj repository.
3. V **Environment Variables** přidej stejné čtyři proměnné jako v `.env.local`.
4. Klikni **Deploy**.

## 5. Stránky
- `/` – úvodní stránka
- `/whitelist` – podání žádosti
- `/status` – kontrola stavu podle kontrolního kódu
- `/admin` – přihlášení A-TEAM
- `/admin/dashboard` – přehled žádostí
- `/admin/dashboard/[id]` – detail a rozhodnutí o žádosti

## Bezpečnostní poznámky před ostrým spuštěním
- Změň počáteční heslo `1923` a nastav dlouhý náhodný `ADMIN_SESSION_SECRET`.
- Service Role key musí zůstat pouze na serveru ve Vercel Environment Variables.
- Veřejný endpoint formuláře je vhodné před zveřejněním doplnit o CAPTCHA a rate limiting proti spamu.
- Zveřejni jasné zásady ochrany osobních údajů a sbírej jen údaje, které skutečně potřebuješ. Věk a kontaktní údaje neposílej dál bez důvodu.
- Streamovací souhlas je dobrovolný; text uprav podle skutečných pravidel komunity.
- Aplikace je komunitní projekt, není oficiálně spojena s Robloxem ani Emergency Hamburg.

## Poznámka
Vzhled a formulář jsou připravené jako výchozí verze. Kontrolní heslo z pravidel nastavíš podle vlastního textu pravidel serveru.
