"use client";export default function LogoutButton(){return <button className="button" onClick={async()=>{await fetch("/api/admin/logout",{method:"POST"});location.href="/admin";}}>Odhlásit</button>}
