import {NextResponse} from "next/server";import {randomBytes} from "node:crypto";import {getSupabase} from "@/lib/supabase";
export const runtime="nodejs";
const required=["discord_name","discord_id","game_name","age","experience","microphone","rp_terms","server_rules","scenario","secret_word","character_name","birth_date","nationality","lore","personality","strengths_weaknesses","goals"];
export async function POST(req:Request){try{const body=await req.json();for(const key of required){if(body[key]===undefined||String(body[key]).trim()==="")return NextResponse.json({error:"Vyplň prosím všechna povinná pole."},{status:400});}
if(!body.rules_consent)return NextResponse.json({error:"Pro odeslání musíš potvrdit souhlas s pravidly."},{status:400});
const age=Number(body.age);if(!Number.isInteger(age)||age<1||age>99)return NextResponse.json({error:"Zadej platný věk."},{status:400});
if(body.steam_url&&!/^https?:\\/\\//i.test(body.steam_url))return NextResponse.json({error:"Odkaz na Steam musí začínat http:// nebo https://."},{status:400});
const code=randomBytes(4).toString("hex").toUpperCase().match(/.{1,4}/g)!.join("-");
const payload=Object.fromEntries([...required,"steam_url","rules_consent","stream_consent"].map(k=>[k,body[k]??null]));
const {error}=await getSupabase().from("applications").insert({...payload,age,code,status:"pending"});
if(error){console.error(error);return NextResponse.json({error:"Uložení žádosti se nezdařilo. Zkus to prosím později."},{status:500});}
return NextResponse.json({code});}catch(e){console.error(e);return NextResponse.json({error:"Server není správně nakonfigurován."},{status:500});}}
