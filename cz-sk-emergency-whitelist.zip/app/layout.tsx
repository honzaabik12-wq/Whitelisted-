import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CZ/SK Styl Emergency Hamburg | Whitelist",
  description: "Whitelist portál CZ/SK Styl Emergency Hamburg.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="cs">
      <body>{children}</body>
    </html>
  );
}
