import Link from "next/link";
export default function Home() {
  return <main className="shell">
    <header className="topbar">
      <Link className="brand" href="/"><span className="brandmark">✦</span><span>CZ/SK EMERGENCY<small>ROLEPLAY • WHITELIST PORTAL</small></span></Link>
      <nav className="nav"><Link href="/status">Stav žádosti</Link><Link className="button" href="/admin">A-TEAM</Link></nav>
    </header>
    <section className="hero">
      <div><div className="eyebrow">Czech & Slovak Emergency Community</div><h1>VSTUP DO<br/><span>SLUŽBY.</span></h1><p className="lead">Vítej v náborovém portálu CZ/SK Styl Emergency Hamburg. Vyplň whitelist žádost, ukaž své znalosti pravidel a představ nám svou postavu. Každá žádost je posuzována členy A-TEAM.</p><div style={{display:"flex",gap:10,flexWrap:"wrap",marginTop:25}}><Link className="button primary" href="/whitelist">Podat whitelist žádost →</Link><Link className="button" href="/status">Zkontrolovat stav</Link></div></div>
      <aside className="hero-card"><div className="stripe"/><div className="eyebrow">APPLICATION CENTER / 01</div><h2 style={{font:"700 32px 'Barlow Condensed'",margin:"9px 0"}}>PŘIPRAVEN NA ROLEPLAY?</h2><p className="muted" style={{fontSize:13,lineHeight:1.7}}>Před odesláním si připrav Discord údaje, herní přezdívku a promyšlený příběh své postavy.</p><div className="statrow"><div className="stat"><strong>04</strong><span>ČÁSTI ŽÁDOSTI</span></div><div className="stat"><strong>100%</strong><span>RP ZAMĚŘENÍ</span></div></div><div style={{marginTop:18,fontSize:11,color:"#9fb0c4"}}>● WHITELIST PORTAL <span style={{float:"right"}}>CZ / SK</span></div></aside>
    </section>
    <section className="section"><div className="sectionhead"><div className="eyebrow">JAK TO FUNGUJE</div><h2>ČTYŘI KROKY K PŘIJETÍ</h2><p>Vyplň všechny části co nejpřesněji. Kvalitní a vlastní odpovědi mají větší hodnotu než krátké obecné věty.</p></div>
      <div className="steps"><div className="step"><b>01 / OOC</b><strong>Základní údaje</strong><p>Discord, herní účet, věk, zkušenosti a mikrofon.</p></div><div className="step"><b>02 / RULES</b><strong>Pravidla a pojmy</strong><p>RP terminologie, modelové situace a kontrolní heslo.</p></div><div className="step"><b>03 / IC</b><strong>Tvoje postava</strong><p>Jméno, životopis, povaha a cíle ve městě.</p></div><div className="step"><b>04 / FINAL</b><strong>Potvrzení</strong><p>Souhlasy a odeslání žádosti A-TEAM.</p></div></div>
    </section>
    <footer className="footer"><span>© {new Date().getFullYear()} CZ/SK Styl Emergency Hamburg</span><span>Neoficiální komunitní projekt pro Roblox Emergency Hamburg.</span></footer>
  </main>;
}
