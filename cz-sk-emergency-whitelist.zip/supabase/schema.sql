-- Spusť celý tento SQL skript v Supabase: SQL Editor -> New query -> Run.
create extension if not exists pgcrypto;

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  discord_name text not null,
  discord_id text not null,
  game_name text not null,
  steam_url text,
  age integer not null,
  experience text not null,
  microphone text not null,
  rp_terms text not null,
  server_rules text not null,
  scenario text not null,
  secret_word text not null,
  character_name text not null,
  birth_date date not null,
  nationality text not null,
  lore text not null,
  personality text not null,
  strengths_weaknesses text not null,
  goals text not null,
  rules_consent boolean not null default false,
  stream_consent boolean not null default false,
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists applications_created_at_idx on public.applications(created_at desc);
create index if not exists applications_status_idx on public.applications(status);

-- Vypni přímý přístup z klienta. Server používá pouze Service Role key.
alter table public.applications enable row level security;
revoke all on public.applications from anon, authenticated;
